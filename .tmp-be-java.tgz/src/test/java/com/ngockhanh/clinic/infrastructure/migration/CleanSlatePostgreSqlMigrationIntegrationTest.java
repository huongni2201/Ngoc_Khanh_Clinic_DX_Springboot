package com.ngockhanh.clinic.infrastructure.migration;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.util.UUID;
import org.flywaydb.core.Flyway;
import org.junit.jupiter.api.Test;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;
import org.testcontainers.postgresql.PostgreSQLContainer;

@Testcontainers(disabledWithoutDocker = true)
class CleanSlatePostgreSqlMigrationIntegrationTest {

  @Container
  static final PostgreSQLContainer POSTGRES =
      new PostgreSQLContainer("postgres:18-alpine")
          .withDatabaseName("nkclinic_clean_slate")
          .withUsername("nkclinic")
          .withPassword("test-password");

  @Test
  void migratesCleanSlateIntoPublicAndEnforcesPatientAndAuditConstraints() {
    Flyway flyway =
        Flyway.configure()
            .dataSource(POSTGRES.getJdbcUrl(), POSTGRES.getUsername(), POSTGRES.getPassword())
            .locations("classpath:db/migration")
            .defaultSchema("public")
            .schemas("public")
            .load();

    assertThat(flyway.migrate().migrationsExecuted).isEqualTo(2);
    flyway.validate();
    assertThat(flyway.migrate().migrationsExecuted).isZero();

    JdbcTemplate jdbc =
        new JdbcTemplate(
            new DriverManagerDataSource(
                POSTGRES.getJdbcUrl(), POSTGRES.getUsername(), POSTGRES.getPassword()));

    assertThat(
            jdbc.queryForObject(
                "SELECT count(*) FROM information_schema.columns WHERE table_schema = 'public' AND table_name = 'organizations' AND column_name IN ('organization_type', 'contact_position')",
                Integer.class))
        .isZero();

    assertThat(
            jdbc.queryForList(
                """
                SELECT table_name FROM information_schema.tables
                WHERE table_schema = 'public' AND table_type = 'BASE TABLE'
                  AND table_name <> 'flyway_schema_history'
                """,
                String.class))
        .hasSize(64)
        .contains(
            "accounts",
            "staff_members",
            "health_examination_batch_participants",
            "health_examination_participant_services",
            "result_versions",
            "issued_representations",
            "audit_events");
    assertThat(
            jdbc.queryForList(
                """
                SELECT nspname FROM pg_namespace
                WHERE nspname NOT LIKE 'pg_%' AND nspname <> 'information_schema'
                """,
                String.class))
        .containsExactly("public");
    assertThat(
            jdbc.queryForObject(
                """
                SELECT count(*) FROM pg_constraint c
                JOIN pg_class source ON source.oid = c.conrelid
                JOIN pg_namespace source_schema ON source_schema.oid = source.relnamespace
                JOIN pg_class target ON target.oid = c.confrelid
                JOIN pg_namespace target_schema ON target_schema.oid = target.relnamespace
                WHERE c.contype = 'f' AND source_schema.nspname = 'public'
                  AND target_schema.nspname <> 'public'
                """,
                Integer.class))
        .isZero();

    UUID patientId =
        jdbc.queryForObject(
            """
            INSERT INTO public.patients
              (patient_code, full_name, date_of_birth, sex, identification_number, status)
            VALUES ('TEST-001', 'Test Patient', DATE '2000-01-01', 'MALE', '000000000001', 'ACTIVE')
            RETURNING id
            """,
            UUID.class);
    assertThat(patientId).isNotNull();
    assertThat(patientId.version()).isEqualTo(7);
    assertThatThrownBy(
            () ->
                jdbc.update(
                    """
                    INSERT INTO public.patients
                      (patient_code, full_name, date_of_birth, sex, identification_number, status)
                    VALUES ('TEST-002', 'Test Patient', DATE '2000-01-01', 'MALE', '000000000001', 'ACTIVE')
                    """))
        .isInstanceOf(DataIntegrityViolationException.class);

    UUID auditId =
        jdbc.queryForObject(
            """
            INSERT INTO public.audit_events (action, resource_type, resource_id)
            VALUES ('PATIENT_CREATED', 'PATIENT', ?) RETURNING id
            """,
            UUID.class,
            patientId);
    assertThatThrownBy(
            () ->
                jdbc.update(
                    "UPDATE public.audit_events SET action = 'CHANGED' WHERE id = ?", auditId))
        .isInstanceOf(DataAccessException.class);
    assertThatThrownBy(() -> jdbc.update("DELETE FROM public.audit_events WHERE id = ?", auditId))
        .isInstanceOf(DataAccessException.class);
    assertThat(
            jdbc.queryForObject(
                "SELECT action FROM public.audit_events WHERE id = ?", String.class, auditId))
        .isEqualTo("PATIENT_CREATED");
  }
}
